#!/bin/bash
while true
do
 node /home/admin/Websites/trajan/escrow-scheduler.js
 sleep 1
done
