(function(angular) {
    'use strict';

    angular
        .module('imageCropper', []);

})(angular);
