(function(angular) {
    'use strict';

    angular
        .module('app', [
            'imageCropper'
        ]);

})(angular);
