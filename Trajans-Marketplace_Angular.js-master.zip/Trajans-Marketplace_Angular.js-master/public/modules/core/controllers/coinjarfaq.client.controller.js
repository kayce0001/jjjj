'use strict';
/*global $:false  */
angular.module('core').controller('CoinjarfaqController', ['$scope',
	function($scope) {
		$('html, body').animate({
            scrollTop: 0
        }, 100);
		// Controller Logic
		// ...
	}
]);