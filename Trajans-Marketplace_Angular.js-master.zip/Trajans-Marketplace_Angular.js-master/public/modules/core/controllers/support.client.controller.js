'use strict';
/*global $:false  */
angular.module('core').controller('SupportController', ['$scope',
	function($scope) {
		$('html, body').animate({
            scrollTop: 0
        }, 100);
	}
]);