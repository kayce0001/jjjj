'use strict';

/*global $:false */

angular.module('core').factory('ReviewFactory', [
    function() {
        var reviewFactory = {};


        return reviewFactory;
    }
]);
